<?php
return [
    // user profile image save path
    'USER_UPLOAD_IMAGES_PATH' => '/public/backend/images/users/',
    'USER_UPLOAD_IMAGES_PUBLIC_PATH' => '/public/storage/backend/images/users/',
];
?>