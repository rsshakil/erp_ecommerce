<?php

return [
    'merchant_name' => 'Merchant Name',
    'product_code' => 'Product Code',
    'add_new' => 'Add New',
    'add_goods' => 'Add Goods',
    'add_service' => 'Add Service',
    'add_asset' => 'Add Asset',
    'add_stationary' => 'Add Stationary',
    'add_raw_metarial' => 'Add Raw metarial',
    'imports' => 'Import',

];