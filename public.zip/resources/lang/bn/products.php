<?php

return [
    'merchant_name' => 'ব্যবসায়ীর নাম',
    'product_code' => 'পণ্য কোড',
    'add_new' => 'Add New',
    'add_goods' => 'Add Goods',
    'add_service' => 'Add Service',
    'add_asset' => 'Add Asset',
    'add_stationary' => 'Add Stationary',
    'add_raw_metarial' => 'Add Raw metarial',
    'imports' => 'Imports',

];