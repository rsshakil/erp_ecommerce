<template>
  	<div class="footer main-footer d-flex p-2 px-3 bg-white border-top">
  		<span class="copyright ml-auto my-auto mr-2">Copyright © 2019
		<a href="https://dhakajacos.com.bd" rel="nofollow" target="_blank">Jacos team</a>
	</span>
	</div>

	
</template>

<script>
export default {

}
</script>
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
}
</style>