<template>
    <div>
        <form class="form" @submit.prevent="processData()">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Name</label>
                                        <input type="hidden" name="client_id" v-model="inputData.client_id"/>
                                        <input type="text" name="full_name" class="form-control" v-model="inputData.full_name" placeholder="Name">
                                    </div>
                                </div><!--col-6 end-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Phone Number</label>
                                        <input type="text" name="phone" class="form-control" v-model="inputData.phone" placeholder="Phone number">
                                        <input type="hidden" name="mobile" class="form-control" v-model="inputData.phone" placeholder="Phone number">
                                    </div>
                                </div><!--col-6 end-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Email</label>
                                        <input type="text" name="email" class="form-control" v-model="inputData.email" placeholder="Addresss">
                                    </div>
                                </div><!--col-6 end-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Address</label>
                                        <input type="text" name="address1" class="form-control" v-model="inputData.address1" placeholder="Addresss">
                                    </div>
                                </div><!--col-6 end-->

                            </div>
                        </div>
                        <div class="card-footer">
                           <FormButton :isEdit="isEdit" :backUrl="backUrl"></FormButton>
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>
</template>

<script>
    import mixin from '../Mixin/mixin';

    export default {
        mixins: [mixin],
        data(){
            return {
               smList:[],

                smOptions:[
                    {role:'Asst.SM'},
                    {role:'RSM'},
                    {role:'Sr.RSM'},
                ],
                regions:[],
            }
        },
        created() {
           
            this.generalApi = 'customerdues'
            this.backUrl = '/customerdues'
            this.inputData.client_id = Globals.user_info_client_id
            
            console.log(this.inputData);
            
            this.cardTitle = this.isEdit ? 'Edit Customer/party' : 'Add Customer/party'
           
        },

        methods:{
           
        },


    }

</script>