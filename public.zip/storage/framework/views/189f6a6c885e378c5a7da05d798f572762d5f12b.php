<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Geniecup</title>
    <link rel="shortcut icon" href="<?php echo e(Config::get('app.url') . '/public/backend/images/logo/favicon.ico'); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php echo e(Config::get('app.url').'/public/css/app.css'); ?>">
    <link rel="stylesheet" href="<?php echo e(Config::get('app.url').'/public/css/flag-icon.css'); ?>">
    <link href="<?php echo e(Config::get('app.url').'/public/dashboard/styles/shards-dashboards.1.1.0.min.css'); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(Config::get('app.url').'/public/dashboard/styles/extras.1.1.0.min.css'); ?>">
    <script src="<?php echo e(Config::get('app.url').'/public/js/buttons.js'); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(Config::get('app.url').'/public/css/vue-multiselect.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo e(Config::get('app.url').'/public/css/custom.css'); ?>">
    <?php echo $__env->make('backend.layouts.js_variable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-fluid" id="app"></div>
    <script type="text/javascript">
        var BASE_URL='<?php echo e(URL::to('/')); ?>';
        <?php if(auth()->guard()->check()): ?>
          window.Permissions = <?php echo json_encode(Auth::user()->allPermissions, true); ?>;
       <?php else: ?>
          window.Permissions = [];
       <?php endif; ?>
    </script>
    <script src="<?php echo e(Config::get('app.url').'/public/js/app.js'); ?>"></script>
    <script src="<?php echo e(Config::get('app.url').'/public/js/jquery-3.5.1.min.js'); ?>"></script>
    <script src="<?php echo e(Config::get('app.url').'/public/dashboard/scripts/Chart.min.js'); ?>"></script>
    <script src="<?php echo e(Config::get('app.url').'/public/dashboard/scripts/shards-dashboards.1.1.0.min.js'); ?>"></script>
    <script src="<?php echo e(Config::get('app.url').'/public/js/jquery.sharrre.min.js'); ?>"></script>
    <script src="<?php echo e(Config::get('app.url').'/public/dashboard/scripts/extras.1.1.0.min.js'); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    

</body>

</html><?php /**PATH E:\xammp74\htdocs\geniecup\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>