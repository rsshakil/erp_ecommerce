<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cost extends Model
{
    protected $fillable = ['cost_name'];
    
}
