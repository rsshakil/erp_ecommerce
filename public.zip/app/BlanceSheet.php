<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlanceSheet extends Model
{
    //
}
