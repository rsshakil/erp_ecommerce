<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class users_details extends Model
{
    //
}
