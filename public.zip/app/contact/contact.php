<?php

namespace App\contact;

use Illuminate\Database\Eloquent\Model;

class contact extends Model
{
    //
}
