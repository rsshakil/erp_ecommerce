<?php

namespace App\image;

use Illuminate\Database\Eloquent\Model;

class image_control extends Model
{
    //
}
