<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SellHistory extends Model
{
    //
}
