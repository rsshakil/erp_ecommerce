<?php

namespace App\product;

use Illuminate\Database\Eloquent\Model;

class city_control extends Model
{
    //
}
