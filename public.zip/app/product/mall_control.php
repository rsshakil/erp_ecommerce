<?php

namespace App\product;

use Illuminate\Database\Eloquent\Model;

class mall_control extends Model
{
    //
}
