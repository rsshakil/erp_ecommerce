<?php

namespace App\product;

use Illuminate\Database\Eloquent\Model;

class product_attribute_qty extends Model
{
    //
}
