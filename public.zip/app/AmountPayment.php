<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AmountPayment extends Model
{
    //
}
